/* جسر التطبيق: يعوّض ميزة التنزيل الخاصة بـ Claude بحفظ/مشاركة الملف على أندرويد.
   الصفحة الأصلية تستدعي claude.use("downloads") ثم dl.save({filename,data}) — هنا نوفّرها. */
(function () {
  var cap = window.Capacitor;
  var isNative = !!(cap && cap.isNativePlatform && cap.isNativePlatform());

  function toBase64(blob) {
    return new Promise(function (res, rej) {
      var r = new FileReader();
      r.onload = function () { res(String(r.result).split(",")[1]); };
      r.onerror = function () { rej(new Error("read failed")); };
      r.readAsDataURL(blob);
    });
  }
  function safeName(n) { return String(n).replace(/[\\\/:*?"<>|]+/g, "-"); }

  async function saveNative(opts) {
    var Filesystem = cap.registerPlugin("Filesystem");
    var Share = cap.registerPlugin("Share");
    var name = safeName(opts.filename);
    var b64 = await toBase64(opts.data);
    var w = await Filesystem.writeFile({ path: name, data: b64, directory: "CACHE" });
    try {
      await Share.share({ title: name, files: [w.uri], dialogTitle: "حفظ / مشاركة الجدول" });
    } catch (e) {
      var msg = String((e && e.message) || e).toLowerCase();
      if (msg.indexOf("cancel") !== -1) { var c = new Error("declined"); c.code = "declined"; throw c; }
      throw e;
    }
  }

  async function saveWeb(opts) {
    var url = URL.createObjectURL(opts.data);
    var a = document.createElement("a");
    a.href = url; a.download = safeName(opts.filename);
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(function () { URL.revokeObjectURL(url); }, 4000);
  }

  window.claude = {
    use: async function (name) {
      if (name !== "downloads") return null;
      return { save: function (o) { return isNative ? saveNative(o) : saveWeb(o); } };
    }
  };

  if (isNative) {
    // حدود آمنة للشاشة (شريط الحالة/التنقل) مع الرجوع لـ env() إن لم تتوفر المتغيرات
    var st = document.createElement("style");
    st.textContent = "html{padding-top:var(--safe-area-inset-top,env(safe-area-inset-top,0px))!important;" +
      "padding-bottom:var(--safe-area-inset-bottom,env(safe-area-inset-bottom,0px))!important}";
    document.head.appendChild(st);
  }
})();
