# جداول فن لاند — تطبيق Android

المشروع مبني بـ **Capacitor 8**: نفس صفحة الجدول الحالية (`src/index.html`) تُحزَّم داخل تطبيق أندرويد حقيقي يعمل **بدون إنترنت** (كل شيء محلي، بما فيه الخط والمكتبات). لا يوجد API ولا مفاتيح سرية.

- اسم التطبيق: **جداول فن لاند**
- معرّف التطبيق: `com.funland.schedules`
- الاتجاه: عمودي فقط
- الأيقونة وشاشة التشغيل: تُولَّد من مجلد `assets/`

## المتطلبات (مرة واحدة)
1. **Node.js 22 أو أحدث**
2. **Android Studio** (إصدار Otter 2025.2.1 أو أحدث). يأتي معه JDK 21 ولا تحتاج تثبيته.
3. من Android Studio ← SDK Manager: ثبّت **Android SDK Platform 36** و **Platform-Tools**.

## البناء خطوة بخطوة
افتح الطرفية داخل مجلد المشروع:

```bash
# 1) تثبيت الحزم
npm install

# 2) إنشاء مشروع أندرويد + الأيقونة والسبلاتش + المزامنة + التعديلات (أمر واحد)
npm run android:init

# 3) (اختياري) فتح المشروع في Android Studio
npm run open
```

### نسخة تجريبية Debug APK (للتجربة على هاتفك)
```bash
cd android
./gradlew assembleDebug          # على ويندوز: gradlew.bat assembleDebug
```
الملف: `android/app/build/outputs/apk/debug/app-debug.apk`

تثبيت على الهاتف: انسخ الملف للهاتف وافتحه (فعّل «التثبيت من مصادر غير معروفة»)، أو بالكابل مع تفعيل «تصحيح USB»:
```bash
adb install -r android/app/build/outputs/apk/debug/app-debug.apk
```

## نسخة النشر (Release APK و AAB)

### أ) أنشئ مفتاح التوقيع (مرة واحدة فقط)
```bash
keytool -genkeypair -v -storetype PKCS12 -keystore funland-release.jks -alias funland -keyalg RSA -keysize 2048 -validity 10000
```
**احتفظ بنسخة احتياطية من ملف `funland-release.jks` وكلمة المرور.** ضياعه يمنعك من تحديث التطبيق لاحقاً.

### ب) أنشئ الملف `android/keystore.properties`
```properties
storeFile=../../funland-release.jks
storePassword=كلمة_مرور_المخزن
keyAlias=funland
keyPassword=كلمة_مرور_المفتاح
```
(المسار نسبي لمجلد `android/app`. ضع ملف `.jks` في جذر المشروع كما في المثال.)

### ج) ابنِ
```bash
cd android
./gradlew assembleRelease        # APK موقّع
./gradlew bundleRelease          # AAB لـ Google Play
```
- APK: `android/app/build/outputs/apk/release/app-release.apk`
- AAB: `android/app/build/outputs/bundle/release/app-release.aab`

ارفع ملف الـ AAB إلى Google Play Console (فعّل Play App Signing).

## تعديل الجدول لاحقاً
عدّل `src/index.html` ثم:
```bash
npm run sync
```
وأعد بناء الـ APK.

## ماذا تغيّر عن الموقع الأصلي؟
تغيير واحد ضروري فقط: أزرار **PDF / صورة** كانت تعتمد على ميزة تنزيل خاصة بـ Claude لا توجد في أندرويد. الملف `src/native-bridge.js` يعوّضها: يحفظ الملف ثم يفتح قائمة المشاركة (واتساب، حفظ في الملفات...). بقية الصفحة لم تُعدَّل، والتصميم والبيانات (localStorage) كما هي.

## ملاحظات
- صلاحية `INTERNET` تركتها كما يضيفها Capacitor افتراضياً لأن الصفحة تُخدَّم عبر `https://localhost` داخل التطبيق. التطبيق نفسه لا يتصل بالإنترنت.
- إذا ظهر رأس الصفحة تحت شريط الحالة، أو لم يعمل أمر في `patch`، أرسل لي رسالة الخطأ وأصلحها.
