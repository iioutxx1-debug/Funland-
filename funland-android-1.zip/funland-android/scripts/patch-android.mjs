// يعدّل مشروع android/ بعد إنشائه: اتجاه عمودي + إعداد توقيع النسخة النهائية. آمن للتشغيل أكثر من مرة.
import fs from "node:fs";
import path from "node:path";

const root = path.resolve(path.dirname(new URL(import.meta.url).pathname.replace(/^\/([A-Za-z]:)/, "$1")), "..");
const manifest = path.join(root, "android/app/src/main/AndroidManifest.xml");
const gradle = path.join(root, "android/app/build.gradle");
if (!fs.existsSync(manifest) || !fs.existsSync(gradle)) { console.error("مجلد android غير موجود. شغّل: npm run android:init"); process.exit(1); }

// 1) الاتجاه العمودي
let m = fs.readFileSync(manifest, "utf8");
if (!m.includes("android:screenOrientation")) {
  m = m.replace(/<activity\b/, '<activity\n            android:screenOrientation="portrait"');
  fs.writeFileSync(manifest, m);
  console.log("manifest: تم قفل الاتجاه العمودي");
}

// 2) توقيع النسخة النهائية من android/keystore.properties
let g = fs.readFileSync(gradle, "utf8");
if (!g.includes("// funland-signing")) {
  const head = `
// funland-signing
def keystorePropertiesFile = rootProject.file("keystore.properties")
def keystoreProperties = new Properties()
if (keystorePropertiesFile.exists()) { keystoreProperties.load(new FileInputStream(keystorePropertiesFile)) }
`;
  g = g.replace(/(apply plugin: ['"]com\.android\.application['"]\s*\n)/, "$1" + head);
  g = g.replace(/(\n\s*)buildTypes\s*\{/, `$1signingConfigs {
        release {
            if (keystorePropertiesFile.exists()) {
                storeFile file(keystoreProperties['storeFile'])
                storePassword keystoreProperties['storePassword']
                keyAlias keystoreProperties['keyAlias']
                keyPassword keystoreProperties['keyPassword']
            }
        }
    }
$1buildTypes {`);
  g = g.replace(/(buildTypes\s*\{\s*release\s*\{)/, `$1\n            if (keystorePropertiesFile.exists()) { signingConfig signingConfigs.release }`);
  if (!g.includes("signingConfigs.release")) { console.error("تعذّر تعديل build.gradle تلقائياً — راجع README (قسم التوقيع اليدوي)"); process.exit(1); }
  fs.writeFileSync(gradle, g);
  console.log("build.gradle: تم إعداد التوقيع");
}
