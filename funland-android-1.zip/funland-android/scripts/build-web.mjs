// يجهّز مجلد www من src/index.html دون تعديل الأصل:
// 1) ينسخ مكتبتي html2canvas و jsPDF محلياً (ليعمل التطبيق بدون إنترنت)
// 2) يضيف native-bridge.js قبل أول سكربت
import fs from "node:fs";
import path from "node:path";

const root = path.resolve(path.dirname(new URL(import.meta.url).pathname.replace(/^\/([A-Za-z]:)/, "$1")), "..");
const www = path.join(root, "www");
const libs = path.join(www, "libs");
fs.rmSync(www, { recursive: true, force: true });
fs.mkdirSync(libs, { recursive: true });

const need = [
  ["node_modules/html2canvas/dist/html2canvas.min.js", "libs/html2canvas.min.js"],
  ["node_modules/jspdf/dist/jspdf.umd.min.js", "libs/jspdf.umd.min.js"],
];
for (const [from, to] of need) {
  const src = path.join(root, from);
  if (!fs.existsSync(src)) { console.error("ملف ناقص: " + from + "\nشغّل: npm install"); process.exit(1); }
  fs.copyFileSync(src, path.join(www, to));
}
fs.copyFileSync(path.join(root, "src/native-bridge.js"), path.join(www, "native-bridge.js"));

let html = fs.readFileSync(path.join(root, "src/index.html"), "utf8");
const cdn1 = /https:\/\/cdnjs\.cloudflare\.com\/ajax\/libs\/html2canvas\/[^"]+/;
const cdn2 = /https:\/\/cdnjs\.cloudflare\.com\/ajax\/libs\/jspdf\/[^"]+/;
if (!cdn1.test(html) || !cdn2.test(html)) { console.error("لم أجد روابط CDN المتوقعة في src/index.html"); process.exit(1); }
html = html.replace(cdn1, "libs/html2canvas.min.js").replace(cdn2, "libs/jspdf.umd.min.js");
html = html.replace("<script", '<script src="native-bridge.js"></script>\n<script');
fs.writeFileSync(path.join(www, "index.html"), html);
console.log("تم تجهيز www ✔");
